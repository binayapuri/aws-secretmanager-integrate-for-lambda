import json
import os

import boto3
from dotenv import load_dotenv

load_dotenv()

DATA_QUEUE_URL = os.getenv('SQS_URL')
MESSAGE_GROUP_ID = os.getenv('SQS_MESSAGE_GROUP_ID')


def push_to_queue(data):
    SQS_CLIENT = boto3.client('sqs')

    message_body = json.dumps(data)
    if response := SQS_CLIENT.send_message(
        QueueUrl=DATA_QUEUE_URL,
        MessageBody=message_body,
        MessageGroupId=MESSAGE_GROUP_ID
    ):
        return True
    else:
        return False


def pop_from_queue():
    SQS_CLIENT = boto3.client('sqs')
    response = SQS_CLIENT.receive_message(
        QueueUrl=DATA_QUEUE_URL,
        MaxNumberOfMessages=1,
    )

    if messages := response.get('Messages'):
        message = messages[0]
        body = json.loads(message['Body'])
        SQS_CLIENT.delete_message(
            QueueUrl=DATA_QUEUE_URL,
            ReceiptHandle=message['ReceiptHandle']
        )
        return body

    return None
