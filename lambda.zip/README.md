
## 1. ENV
S3_BUCKET_NAME = adex_gpt_data_bucket <br>
SERVICE_ACCOUNT_FILE = secret/client_secret.json #path to client_secret.json for DRIVE <br>
DATA_FILE = /data/data_files #path to data file, dont change, keep this <br>
CONFLUENCE_API_TOKEN = <br>
CONFLUENCE_USER = <br>
JIRA_INSTANCE = example.atlassian.net <br>
SQS_URL = <br>
SQS_MESSAGE_GROUP_ID = <br>
