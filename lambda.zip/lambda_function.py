from .confluence_extractor import confluence
from .drive_extractor import drive
from .jira import issue_detail
from .sqs import push_to_queue


def lambda_handler(event, context):
    completed = False
    if issue_id := event['issue_id']:
        issue_description = issue_detail(issue_id)
        source = issue_description[0]
        model = issue_description[1]
        match source.lower():
            case 'drive':
                completed = drive(model)
            case 'confluence':
                space_id = issue_description[2]
                completed = confluence(model, space_id)
            case _:
                completed = False

        if completed:
            push_to_queue({
                'issue_id': issue_id,
                'source': source,
                'model': model
            })
            status = 200
        else:
            status = 400
    else:
        status = 400

    return {
        'statusCode': status,
        'body': {
            'status': completed
        }
    }
