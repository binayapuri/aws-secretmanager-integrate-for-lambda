import io
import json
import os

import boto3
from dotenv import load_dotenv
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaIoBaseDownload

load_dotenv()

SERVICE_ACCOUNT_FILE = os.getenv('SERVICE_ACCOUNT_FILE')
S3_BUCKET_NAME = os.getenv('S3_BUCKET_NAME')
DATA_FILE = os.getenv('DATA_FILE')

SCOPES = ['https://www.googleapis.com/auth/drive']
s3 = boto3.client('s3')


def save_to_s3(file_name, model_name):
    with open(f'{file_name}', 'rb') as data:
        s3.upload_fileobj(data, S3_BUCKET_NAME,
                          f'{DATA_FILE}/drive/{model_name}/{file_name}')
    # os.remove(f"{file_name}")


def download_files_from_folder(folder_id, service, model_name):
    results = service.files().list(
        q=f"'{folder_id}' in parents and mimeType!='application/vnd.google-apps.folder'",
        fields='files(id, name, mimeType)'
    ).execute()

    if not (files := results.get('files', [])):
        print(f'No files found in the folder with ID {folder_id}')
        return

    for file in files:
        file_id = file['id']
        file_name = file['name']

        # It's a file, download it
        request = service.files().get_media(fileId=file_id)

        with io.FileIO(file_name, 'wb') as fh:
            downloader = MediaIoBaseDownload(fh, request)
            done = False

            while not done:
                status, done = downloader.next_chunk()
                print(
                    f'Downloaded {int(status.progress() * 100)}% for: {file_name}')
        save_to_s3(file_name, model_name)


def drive(model_name):
    creds = Credentials.from_service_account_info(
        json.loads(SERVICE_ACCOUNT_FILE), scopes=SCOPES)

    drive_service = build('drive', 'v3', credentials=creds)

    # Fetch the 'Master' folder
    results_master = drive_service.files().list(
        q="name='Training_Data' and mimeType='application/vnd.google-apps.folder'",
        fields='files(id)'
    ).execute()
    master_folder_id = results_master.get('files', [])[0]['id']

    # Fetch symlinks (shortcuts) and folders inside the 'Master' folder
    folder_results = drive_service.files().list(
        q=f"(name='{model_name}' and '{master_folder_id}' in parents and mimeType='application/vnd.google-apps.shortcut')",
        fields='files(id, shortcutDetails)'
    ).execute()

    if not folder_results['files']:  # for folder
        results_master = drive_service.files().list(
            q="name='Training_Data' and mimeType='application/vnd.google-apps.folder'",
            fields='files(id)'
        ).execute()
        master_folder_id = results_master.get('files', [])[0]['id']
        folder_results = drive_service.files().list(
            q=f"(name='{model_name}' and '{master_folder_id}' in parents and mimeType='application/vnd.google-apps.folder')",
            fields='files(id)'
        ).execute()
        for folder in folder_results.get('files', []):
            folder_id = folder['id']
            download_files_from_folder(folder_id, drive_service, model_name)
        return True

    elif not not folder_results['files']:  # for symlink
        for item in folder_results.get('files', []):
            if 'shortcutDetails' in item:
                # It's a symlink (shortcut)
                folder_target_id = item['shortcutDetails']['targetId']

                # List content inside the symlinked folder
                folder_content_results = drive_service.files().list(
                    q=f"'{folder_target_id}' in parents",
                    fields='files(id, name, mimeType)'
                ).execute()
                folder_content_items = folder_content_results.get('files', [])

                # Download each file inside the symlinked folder
                for content_item in folder_content_items:
                    file_id = content_item['id']
                    file_name = content_item['name']
                    file_mimeType = content_item['mimeType']

                    # If the item is a file, download it; skip if it's a folder
                    if 'folder' not in file_mimeType:
                        request = drive_service.files().get_media(fileId=file_id)

                        fh = io.FileIO(f'{file_name}', 'wb')
                        downloader = MediaIoBaseDownload(fh, request)
                        done = False

                        while not done:
                            status, done = downloader.next_chunk()
                            print(
                                f'Downloaded {int(status.progress() * 100)}%.')
                    save_to_s3(file_name, model_name)
        return True
    else:
        return False


if __name__ == '__main__':
    MODEL_NAME = 'HR'
    drive(MODEL_NAME)
