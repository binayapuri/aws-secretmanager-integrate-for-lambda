'''
curl -u test@gmail.com:api_key -X GET "https://example.atlassian.net/rest/api/3/issue/{issue_id}/transitions"
'''
import json
import logging
import os

import requests
from dotenv import load_dotenv
from requests.auth import HTTPBasicAuth

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

JIRA_INSTANCE = os.getenv('JIRA_INSTANCE')
API_TOKEN = os.getenv('CONFLUENCE_API_TOKEN')
USER = os.getenv('CONFLUENCE_USER')

BOARD = {
    'initiation': 11,
    'verification': 2,
    'verified': 21,
    'train': 31,
    'done': 22,
    'discarded': 12,
}


auth = HTTPBasicAuth(USER, API_TOKEN)

headers = {
    'Content-Type': 'application/json',
}


def issue_detail(issue_key):
    config = None
    jira_url = f'https://{JIRA_INSTANCE}/rest/api/3/issue/{issue_key}'

    response = requests.get(jira_url, auth=auth, headers=headers)

    if response.status_code == 200:
        issue_details = response.json()
        issue_key = issue_details['key']
        summary = issue_details['fields']['summary']
        description = issue_details['fields']['description']
        config = description['content'][0]['content'][0]['text'].split(',')

        logger.info(
            f'Issue Key: {issue_key}, Summary: {summary}, Description: {description}')
    else:
        logger.error(
            f'Failed to fetch issue details. Status code: {response.status_code}, Response: {response.text}')
    return config


def transition_issue_status(issue_key, transition_id):
    logger.info(f'Changing status of issue {issue_key}')
    api_url = f'https://{JIRA_INSTANCE}/rest/api/3/issue/{issue_key}/transitions'

    headers = {'Accept': 'application/json',
               'Content-Type': 'application/json'}

    transition_data = {
        'transition': {'id': transition_id}
    }

    response = requests.post(api_url, data=json.dumps(
        transition_data), headers=headers, auth=auth)

    if response.status_code == 204:
        logger.info(f'Status changed successfully for issue {issue_key}')
    else:
        logger.error(
            f'Failed to change status. Status code: {response.status_code}, Response: {response.text}')


def add_jira_comment(message, issue_key):
    logger.info(f'Adding comment {message}')
    api_url = f'https://{JIRA_INSTANCE}/rest/api/3/issue/{issue_key}/comment'

    headers = {'Accept': 'application/json',
               'Content-Type': 'application/json'}

    payload = json.dumps(
        {
            'body': {
                'content': [
                    {
                        'content': [{'text': f'Server: ', 'type': 'text', 'marks': [{'type': 'strong'}]},
                                    {'text': message, 'type': 'text'}],
                        'type': 'paragraph',
                    }
                ],
                'type': 'doc',
                'version': 1,
            }
        }
    )

    response = requests.request(
        'POST', api_url, data=payload, headers=headers, auth=auth
    )
    logger.info(response)


def board_detail(board_id):
    jira_url = 'https://{JIRA_INSTANCE}/rest/agile/1.0/board/{board_id}'
    response = requests.get(jira_url, auth=auth, headers=headers)

    if response.status_code == 200:
        board_info = response.json()
        print(board_info)
        board_id = board_info['id']
        board_name = board_info['name']
        logger.info(f'Board ID: {board_id}, Board Name: {board_name}')
    else:
        logger.error(
            f'Failed to fetch board info. Status code: {response.status_code}, Response: {response.text}')

# if __name__ == "__main__":
#     issue_id = 'CA-1'
#     source , model = issue_detail(issue_id)
#     add_jira_comment('Started training' , issue_id)
#     transition_issue_status(issue_id,BOARD['train'])

#     print(source)
#     print(model)
