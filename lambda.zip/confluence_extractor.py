import os

import boto3
import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv
from requests.auth import HTTPBasicAuth

load_dotenv()

S3_BUCKET_NAME = os.getenv('S3_BUCKET_NAME')
DATA_FILE = os.getenv('DATA_FILE')
API_TOKEN = os.getenv('CONFLUENCE_API_TOKEN')
USER = os.getenv('CONFLUENCE_USER')
JIRA_INSTANCE = os.getenv('JIRA_INSTANCE')

auth = HTTPBasicAuth(USER, API_TOKEN)

headers = {
    'Content-Type': 'application/json',
}

s3 = boto3.client('s3')


def save_to_s3(file_name):
    with open(f'{file_name}', 'rb') as data:
        s3.upload_fileobj(data, S3_BUCKET_NAME,
                          f'{DATA_FILE}/confluence/{file_name}')
    # os.remove(f"{file_name}")


def board_detail(space_id):
    jira_url = f'https://{JIRA_INSTANCE}/wiki/rest/api/space/{space_id}/content?limit=100'
    response = requests.get(jira_url, auth=auth, headers=headers)

    if response.status_code == 200:
        board_info = response.json()
        final_text = list()
        for index, page in enumerate(board_info['page']['results']):
            if body := content_detail(page['title'], space_id):
                final_text.append(
                    f"{index}.Title: {page['title']} Body:{body}")

        # print(len(final_text))
        return final_text
    else:
        return None


def content_detail(page_title, space_key):
    page_params = {
        'spaceKey': space_key,
        'title': page_title,
        'expand': 'body.view',
    }

    jira_url = f'https://{JIRA_INSTANCE}/wiki/rest/api/content'

    response = requests.get(jira_url, auth=auth,
                            headers=headers, params=page_params)

    if response.status_code == 200:
        page_data = response.json()
        page_content = page_data['results'][0]['body']['view']['value']
        # print(page_content)

        soup = BeautifulSoup(page_content, 'html.parser')
        plain_text = soup.get_text(separator=' ', strip=True)
        # print(plain_text)
        return plain_text
    else:
        return None


def confluence(space_name, space_id):

    if data := board_detail(space_id):
        with open(f'{space_name}.txt', 'w', encoding='utf-8') as file:
            for line in data:
                file.write(line + '\n')

        save_to_s3(f'{space_name}.txt')
        return True
    else:
        return False


# if __name__ == "__main__":
#     # page_title = '851969'
#     # content_detail(page_title)
#     space_id = '~712020c47cbdcacc5d49d6a4b4a153bd510c33'
#     final = board_detail(space_id)
