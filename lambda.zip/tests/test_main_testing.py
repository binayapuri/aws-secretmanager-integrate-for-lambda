import unittest

# from main import get_embedd


class TestAddFunction(unittest.TestCase):
    def test_print(self):
        self.assertGreaterEqual(1, 1)


if __name__ == '__main__':
    unittest.main()
